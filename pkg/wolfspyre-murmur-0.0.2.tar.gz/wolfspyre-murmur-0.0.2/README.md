puppet-murmur
================

A Linux Murmur server module
